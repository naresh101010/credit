import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-vehicle-make',
  templateUrl: './edit-vehicle-make.component.html',
})
export class EditVehicleMakeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
