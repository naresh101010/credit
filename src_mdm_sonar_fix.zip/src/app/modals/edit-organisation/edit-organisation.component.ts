import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-organisation',
  templateUrl: './edit-organisation.component.html',
})
export class EditOrganisationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  logisticObj
}
