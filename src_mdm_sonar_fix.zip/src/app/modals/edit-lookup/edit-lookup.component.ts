import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-lookup',
  templateUrl: './edit-lookup.component.html',
})
export class EditLookupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
