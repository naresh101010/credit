export class ListOfBusiness {
    "id"?: number;
    "descr"?: string;
    "lkpLobId": number;
    "status": number;
}