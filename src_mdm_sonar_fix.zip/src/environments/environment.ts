export const environment = {
    production: false,
    localApiUrl: "http://localhost:3000/secure/",
    geoApiUrl: "http://internal-aa18f5df64d5e11ea9bac0a3257c4306-287532085.ap-south-1.elb.amazonaws.com/secure/",
    zoneApiUrl: "http://internal-a0e01a3894c0811ea9bac0a3257c4306-2035179949.ap-south-1.elb.amazonaws.com/secure/",
    lookupNotepadApiUrl: "http://internal-a8b998f554e6611ea9bac0a3257c4306-1036323921.ap-south-1.elb.amazonaws.com/secure/",
    commandmentApiUrl: "http://internal-a0db0192d644a11eaa19a023e3146bec-1307889661.ap-south-1.elb.amazonaws.com/secure/",
    branchApiUrl: "http://internal-acb12892e52e311ea9bac0a3257c4306-550481844.ap-south-1.elb.amazonaws.com/secure/",


};
