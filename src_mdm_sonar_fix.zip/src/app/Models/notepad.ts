export class notepad {
    id?: number;
    menuFullId?: string;
    menuLabel?: string;
    notepadName?: string;
    effectiveDate?: string;
    expiryDate?: string;
    attributeIdentifier?: string;
    notepadOrder?: string;
    status?: number;
    attributeTypeId?: number;
    description?: string;
    isVisible?:true;
    isHidden?:false;

}