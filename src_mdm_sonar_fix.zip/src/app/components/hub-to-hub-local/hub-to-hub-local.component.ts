import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hub-to-hub-local',
  templateUrl: './hub-to-hub-local.component.html',
  styleUrls: ['./hub-to-hub-local.component.css']
})
export class HubToHubLocalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
showRoute;
isExpand;
routeSubmit;
searchPoint;
assigSchedule;
}
