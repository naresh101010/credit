import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delivery-local-route',
  templateUrl: './delivery-local-route.component.html',
  styleUrls: ['./delivery-local-route.component.css']
})
export class DeliveryLocalRouteComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
showRoute;
isExpand;
routeSubmit;
searchPoint;
assigSchedule;
}
