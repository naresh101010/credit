import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-metro',
  templateUrl: './metro.component.html',
})
export class MetroComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
  gstObj = {} as any;
  today;
}
