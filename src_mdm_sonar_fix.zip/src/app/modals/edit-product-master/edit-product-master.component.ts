import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-product-master',
  templateUrl: './edit-product-master.component.html',
})
export class EditProductMasterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
