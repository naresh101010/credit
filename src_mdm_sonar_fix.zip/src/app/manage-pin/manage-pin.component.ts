import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-pin',
  templateUrl: './manage-pin.component.html',
})
export class ManagePinComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
