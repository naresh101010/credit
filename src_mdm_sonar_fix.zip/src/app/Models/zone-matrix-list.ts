export class ZoneMatrixList {
    "id": number;
    "name": string;
    "price": number;
    "sla": number;
    "status": number;
    "zmLzMapId": number;
    "states"?:any;

}