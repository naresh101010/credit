export class lookUp {
    id?: number;
    description?: string;
    effectiveDate?: string;
    expiryDate?: string;
    propelRefId?: number;
    status?: number;

}
//   zmLzMapDTO?: __model.ZmLzMapDTO[];
//   zmRGMapDTO?: __model.ZmRGMapDTO[];
