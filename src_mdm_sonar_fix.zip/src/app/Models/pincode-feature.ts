export class PincodeFeature {
    id?: number;
    descr: string;
    isAddorUncheck: string;
    pincodeFeatureId: number;
    status: number;
}