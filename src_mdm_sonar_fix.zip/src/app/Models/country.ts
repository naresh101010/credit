export class Country {
    id?: number;
    countryName: string;
    descr: string;
    status: number;
    effectiveDate?: string;
    expiryDate?: string;
    isUpdateOrRemove?: string;
    type: number;
    nameWithStatus: string;
}