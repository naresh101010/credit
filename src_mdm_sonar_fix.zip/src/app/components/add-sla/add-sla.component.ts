import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-sla',
  templateUrl: './add-sla.component.html',
})
export class AddSlaComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
