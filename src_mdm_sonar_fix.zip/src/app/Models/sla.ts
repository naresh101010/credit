export class Sla {
    "id"?: number;
    "effectiveDate": Date;
    "expiryDate": Date;
    "price": number;
    "rateGroupId": number;
    "serviceLineId": string;
    "serviceOfferingId": number;
    "sla": number;
}
