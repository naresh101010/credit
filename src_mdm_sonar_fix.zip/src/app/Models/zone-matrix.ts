export class ZoneMatrix {
    id?: number;
    description?: string;
    effectiveDate?: string;
    expiryDate?: string;
    propelRefId?: number;
    status?: number;
    zmLzMapDTO?: Array<any>;
    zmRGMapDTO?: Array<any>;
    zoneMatrixName?: string;

}
//   zmLzMapDTO?: __model.ZmLzMapDTO[];
//   zmRGMapDTO?: __model.ZmRGMapDTO[];
