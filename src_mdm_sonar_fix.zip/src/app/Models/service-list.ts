export class ServiceList {
    "id"?: number;
    "lookupVal": string;
}