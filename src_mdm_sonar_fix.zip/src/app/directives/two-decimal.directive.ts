import { Directive, HostListener, ElementRef, Input } from '@angular/core';
import { NgModel } from '@angular/forms';

@Directive({
    selector: '[appTwoDigitDecimaNumber]'
})
export class TwoDecimalDirective {

    @Input("decimals") decimals: number = 2;

    private check(value: string) {
        if (this.decimals <= 0) {
            return String(value).match(new RegExp(/^\d+$/));
        } else {
            var regExpString =
                "^\\s*((\\d+(\\.\\d{0," +
                this.decimals +
                "})?)|((\\d*(\\.\\d{1," +
                this.decimals +
                "}))))\\s*$";
            return String(value).match(new RegExp(regExpString));
        }
    }

    private run(oldValue) {
        setTimeout(() => {
            let currentValue: string = this.el.nativeElement.value;
            if (currentValue !== '' && !this.check(currentValue)) {
                this.el.nativeElement.value = oldValue;
                this.ngmodel.update.emit(oldValue);
            }
        });
    }

    constructor(private el: ElementRef,private ngmodel: NgModel) { }

    @HostListener("keydown", ["$event"])
    onKeyDown(event: KeyboardEvent) {
        this.run(this.el.nativeElement.value);
    }

    @HostListener("paste", ["$event"])
    onPaste(event: ClipboardEvent) {
        this.run(this.el.nativeElement.value);
    }


}
