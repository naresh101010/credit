import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-booking-hub',
  templateUrl: './booking-hub.component.html',
  styleUrls: ['./booking-hub.component.css']
})
export class BookingHubComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
showRoute;
isExpand;
routeSubmit;
searchPoint;
assigSchedule;
}
