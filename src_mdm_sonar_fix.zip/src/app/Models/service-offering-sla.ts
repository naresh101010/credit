export class ServiceOfferingSla {
    price?: any;
    sla?: number;
    serviceOfferingId?: number;
    effectiveDate?: string;
    expiryDate?: string;
    descr: string;
    effectiveDt: string;
    expDt: string;
    serviceOffering: string;
    id?: any;
    lkpServiceLineId: number;
    propelRefId: number;
    status: number;
    rateGroupId?:number;

    isEdit?:boolean;
}
