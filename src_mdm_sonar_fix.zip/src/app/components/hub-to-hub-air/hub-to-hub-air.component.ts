import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hub-to-hub-air',
  templateUrl: './hub-to-hub-air.component.html',
  styleUrls: ['./hub-to-hub-air.component.css']
})
export class HubToHubAirComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }
showRoute;
isExpand;
routeSubmit;
searchPoint;
assigSchedule;
}
