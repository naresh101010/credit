import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-commandment-order',
  templateUrl: './commandment-order.component.html',
})
export class CommandmentOrderComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
