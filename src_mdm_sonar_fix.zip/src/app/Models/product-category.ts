export class ProdCategory {
    descr?: string;
    effectiveDt?: string;
    expDt?: string;
    id?: number;
    prdctCode?: string;
    prdctCtgyId?: number;
    prdctName?: string;
    propelRefId?: number;
    status?: number;

}
//   zmLzMapDTO?: __model.ZmLzMapDTO[];
//   zmRGMapDTO?: __model.ZmRGMapDTO[];
