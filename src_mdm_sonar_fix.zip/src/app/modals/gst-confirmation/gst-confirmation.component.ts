import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-gst-confirmation',
  templateUrl: './gst-confirmation.component.html',
})
export class GstConfirmationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
