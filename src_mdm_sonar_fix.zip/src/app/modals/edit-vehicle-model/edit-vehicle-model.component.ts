import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-vehicle-model',
  templateUrl: './edit-vehicle-model.component.html',
})
export class EditVehicleModelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
