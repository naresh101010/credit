
export class FuelPrice {
    id: number;
    assocFuelbasePrice: number;
    entityId: number;
    fuelbasePrice: number;
    lkpFuelTypeId: number;
    lkpFuelIndexId: number;
    desc: string;
    fuelbaseDt: string;
    effectiveDt: string;
    expDt: string;
    status: number;
}