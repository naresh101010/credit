import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-commandment-rr',
  templateUrl: './commandment-rr.component.html',
})
export class CommandmentRrComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
