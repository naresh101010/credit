import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-touch-point-confirmation',
  templateUrl: './touch-point-confirmation.component.html',
  styleUrls: ['./touch-point-confirmation.component.css']
})
export class TouchPointConfirmationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
